var clerk = function (i,s){
    this.id=i;
    this.salary=s;
}
clerk.prototype.work=function(){
}
clerk.prototype.fire=function(){
}